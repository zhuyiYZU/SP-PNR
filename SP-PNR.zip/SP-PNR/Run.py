# -*- coding: utf-8 -*-
import logging
import os
import subprocess
import time
from itertools import product

def AutoRun_All():
    logging.basicConfig(level=logging.INFO)  # 配置日志记录器

    # get UsersID list
    userslist = []
    temp = []
    with open("datasets/MIND/MINDsmall-uid.tsv", "r", encoding="utf-8") as fr:
        for line in fr.readlines():
            userID = int(line.split("\t")[0].split("U")[1])
            if userID not in temp:
                temp.append(userID)
        temp.sort()
        for i in temp:
            userslist.append("U" + str(i))
        fr.close()

    # task = ["Subcategory", "Summary"]

    for userID in userslist:
    # for userID in userslist[438:]:
        with open("./result/0001.txt","a",encoding="utf-8") as f:
            f.write(userID + "\n")
            f.close()
        print(userID)

        # for i in range(3):
        for s in ["train", "test"]:
            os.remove("./datasets/MIND/" + s + ".csv")
            with open("./datasets/MIND/" + s + ".csv", "a", encoding="utf-8") as fw:
                if s == "test":
                    # path = "./datasets/MINDsmall/" + userID + "_dev_"+task[i]+".tsv"
                    path = "./datasets/MIND/MINDsmall-488/" + userID + "_dev_ALL.tsv"
                else:
                    # path = "./datasets/MINDsmall/" + userID + "_train_"+task[i]+".tsv"
                    path = "./datasets/MIND/MINDsmall-488/" + userID + "_train_ALL.tsv"
                with open(path, "r", encoding="utf-8") as fr:
                    for line in fr.readlines():
                        fw.write(line)
                    fr.close()
                fw.close()

        lr = {1e-4}  #1e-5, 2e-5, 3e-5, 4e-5
        shots = {60}  # range(40, 81, 20)
        # seeds = {60}  # range(40, 81, 20)
        batch_size = {16}
        template_id = {12,13,14}
        for t, b, m, l in product(template_id,batch_size, shots, lr,):
            cmd = (f"python fewshot.py --template_id {t} --batch_size {b} --shot {m} --learning_rate {l}")
            logging.info(f"Executing command: {cmd}")
            print(cmd)
            try:
                subprocess.run(cmd, shell=True, check=True)
                logging.info(f"Command executed successfully: {cmd}")
            except subprocess.CalledProcessError as e:
                logging.error(f"Command failed: {cmd}. Error: {e.stderr.decode().strip()}")

            time.sleep(2)


if __name__ == '__main__':
    AutoRun_All()
    # solo()





