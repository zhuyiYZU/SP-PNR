import tqdm
from openprompt.data_utils.bas import *
import torch
from openprompt.data_utils.utils import InputExample
import argparse
import numpy as np

from openprompt import PromptDataLoader
from openprompt.prompts import ManualVerbalizer, KnowledgeableVerbalizer, SoftVerbalizer, AutomaticVerbalizer
from openprompt.prompts import ManualTemplate, PtuningTemplate
from openprompt.utils import metrics

from transformers import logging

logging.set_verbosity_warning()
logging.set_verbosity_error()

# 第一步：创建一个解析对象；
parser = argparse.ArgumentParser("")
# 然后向该对象中添加你要关注的命令行参数和选项，每一个add_argument方法对应一个你要关注的参数或选项；
parser.add_argument("--shot", type=int)
parser.add_argument("--seed", type=int, default=18)
parser.add_argument("--template_id", type=int)
parser.add_argument("--verbalizer", type=str, default='manual')
parser.add_argument("--dataset", type=str, default='MIND')
parser.add_argument("--result_file", type=str, default="./result/0701.txt")
parser.add_argument("--model", type=str, default='bert')
parser.add_argument("--model_name_or_path", default="./model/bert-base-cased")
parser.add_argument("--plm_eval_mode", action="store_true")
# parser.add_argument("--model_name_or_path", default='bert-base-chinese')
parser.add_argument("--calibration", action="store_true")
parser.add_argument("--filter", default="none", type=str)
parser.add_argument("--gradient_accumulation_steps", type=int, default=1)
parser.add_argument("--max_epochs", type=int, default=2)
parser.add_argument("--kptw_lr", default=0.06, type=float)
parser.add_argument("--pred_temp", default=1.0, type=float)
parser.add_argument("--max_token_split", default=-1, type=int)
parser.add_argument("--batch_size", type=int)
parser.add_argument("--learning_rate", type=float)
# 最后调用parse_args()方法进行解析；解析成功之后即可使用。
args = parser.parse_args()

import random

this_run_unicode = str(random.randint(0, 1e10))

from openprompt.utils.reproduciblity import set_seed

set_seed(args.seed)

# 第二步：定义预训练语言模型作为主干
from openprompt.plms import load_plm
from transformers import logging

logging.set_verbosity_warning()
# 确定预训练语言模型
plm, tokenizer, model_config, WrapperClass = load_plm(args.model, args.model_name_or_path)  # 这里选择的预训练语言模型是bert

dataset = {}

if args.dataset == "MIND":
    dataset['train'] = MINDProcessor().get_train_examples("./datasets/MIND/")
    dataset['test'] = MINDProcessor().get_test_examples("./datasets/MIND/")
    class_labels = MINDProcessor().get_labels()
    scriptsbase = "MIND"
    scriptformat = "txt"
    cutoff = 0.5
    max_seq_l = 128
    batch_s = args.batch_size
else:
    raise NotImplementedError

# 第三步：模板选择
# Manual
mytemplate = ManualTemplate(tokenizer=tokenizer).from_file(f"./scripts/{scriptsbase}/manual_template.txt", choice=args.template_id)
mytemplate = PtuningTemplate(model=plm, tokenizer=tokenizer).from_file(f"./scripts/{scriptsbase}/ptuning_template.txt", choice=args.template_id)

# 第四步：定义Verbalizer, 将原始标签投射到一组label单词中，如把消极类投射到单词bad，把积极类投射到单词good，wonderful，great

if args.verbalizer == "kpt":
    myverbalizer = KnowledgeableVerbalizer(tokenizer, classes=class_labels, candidate_frac=cutoff,
                                           pred_temp=args.pred_temp, max_token_split=args.max_token_split).from_file(
        f"scripts/{scriptsbase}/knowledgeable_verbalizer.{scriptformat}")
elif args.verbalizer == "manual":
    myverbalizer = ManualVerbalizer(tokenizer, classes=class_labels).from_file(
        f"scripts/{scriptsbase}/manual_verbalizer.{scriptformat}")
elif args.verbalizer == "soft":
    myverbalizer = SoftVerbalizer(tokenizer, plm=plm, classes=class_labels).from_file(
        f"scripts/{scriptsbase}/manual_verbalizer.{scriptformat}")
elif args.verbalizer == "auto":
    myverbalizer = AutomaticVerbalizer(tokenizer, classes=class_labels)

# (contextual) calibration
if args.verbalizer in ["kpt", "manual"]:
    if args.calibration or args.filter != "none":
        from openprompt.data_utils.data_sampler import FewShotSampler

        support_sampler = FewShotSampler(num_examples_total=200, also_sample_dev=False)
        dataset['support'] = support_sampler(dataset['train'], seed=args.seed)

        # for example in dataset['support']:
        #     example.label = -1 # remove the labels of support set for clarification
        support_dataloader = PromptDataLoader(dataset=dataset["support"], template=mytemplate, tokenizer=tokenizer,
                                              tokenizer_wrapper_class=WrapperClass,
                                              max_seq_length=max_seq_l,
                                              decoder_max_length=3,
                                              batch_size=batch_s, shuffle=False, teacher_forcing=False,
                                              predict_eos_token=False,
                                              truncate_method="tail")

# 第五步：构造PromptModel，有三个对象，分别是：PLM,Prompt,Verbalizer
#    将它们合并到PromptModel中
#    给定任务，现在我们有一个PLM、一个模板和一个Verbalizer，我们将它们合并到PromptModel中

from openprompt import PromptForClassification

use_cuda = True
prompt_model = PromptForClassification(plm=plm, template=mytemplate, verbalizer=myverbalizer, freeze_plm=False,
                                       plm_eval_mode=args.plm_eval_mode)
if use_cuda:
    prompt_model = prompt_model.cuda()

# HP
# if args.calibration:
if args.verbalizer in ["kpt", "manual"]:
    if args.calibration or args.filter != "none":
        org_label_words_num = [len(prompt_model.verbalizer.label_words[i]) for i in range(len(class_labels))]
        from openprompt.utils.calibrate import calibrate

        # calculate the calibration logits
        cc_logits = calibrate(prompt_model, support_dataloader)
        print("the calibration logits is", cc_logits)
        print("origial label words num {}".format(org_label_words_num))

    if args.calibration:
        myverbalizer.register_calibrate_logits(cc_logits)
        new_label_words_num = [len(myverbalizer.label_words[i]) for i in range(len(class_labels))]
        print("After filtering, number of label words per class: {}".format(new_label_words_num))
    # register the logits to the verbalizer so that the verbalizer will divide the calibration probability in producing label logits
    # currently, only ManualVerbalizer and KnowledgeableVerbalizer support calibration.

from openprompt.data_utils.data_sampler import FewShotSampler

sampler = FewShotSampler(num_examples_per_label=args.shot, also_sample_dev=True, num_examples_per_label_dev=args.shot)
dataset['train'], dataset['validation'] = sampler(dataset['train'], seed=args.seed)
# 第六步：构造PromptDateLoader，与数据加载和数据处理有关
#    PromptDataLoader基本上是pytorch DataLoader的prompt版本，它还包括一个Tokerizer、一个Template和一个TokenizeerWrapper
train_dataloader = PromptDataLoader(dataset=dataset["train"], template=mytemplate, tokenizer=tokenizer,
                                    tokenizer_wrapper_class=WrapperClass, max_seq_length=max_seq_l,
                                    decoder_max_length=3,
                                    batch_size=batch_s, shuffle=True, teacher_forcing=False, predict_eos_token=False,
                                    truncate_method="tail")

validation_dataloader = PromptDataLoader(dataset=dataset["validation"], template=mytemplate, tokenizer=tokenizer,
                                         tokenizer_wrapper_class=WrapperClass, max_seq_length=max_seq_l,
                                         decoder_max_length=3,
                                         batch_size=batch_s, shuffle=False, teacher_forcing=False,
                                         predict_eos_token=False,
                                         truncate_method="tail")

test_dataloader = PromptDataLoader(dataset=dataset["test"], template=mytemplate, tokenizer=tokenizer,
                                   tokenizer_wrapper_class=WrapperClass, max_seq_length=max_seq_l, decoder_max_length=3,
                                   batch_size=batch_s, shuffle=False, teacher_forcing=False, predict_eos_token=False,
                                   truncate_method="tail")


def evaluate1(prompt_model, dataloader, desc):
    prompt_model.eval()
    allpreds = []
    alllabels = []
    pbar = tqdm.tqdm(dataloader, desc=desc)
    for step, inputs in enumerate(pbar):
        if use_cuda:
            inputs = inputs.cuda()
        logits = prompt_model(inputs)
        labels = inputs['label']
        alllabels.extend(labels.cpu().tolist())
        allpreds.extend(torch.argmax(logits, dim=-1).cpu().tolist())
    # print(alllabels)
    # print(allpreds)
    acc = sum([int(i == j) for i, j in zip(allpreds, alllabels)]) / len(allpreds)
    # Micro_F1 = metrics.classification_metrics(allpreds,alllabels,metric="micro-f1")
    return acc
def evaluate2(prompt_model, dataloader, desc):
    prompt_model.eval()
    allpreds = []
    alllabels = []
    pbar = tqdm.tqdm(dataloader, desc=desc)
    for step, inputs in enumerate(pbar):
        if use_cuda:
            inputs = inputs.cuda()
        logits = prompt_model(inputs)
        labels = inputs['label']
        alllabels.extend(labels.cpu().tolist())
        allpreds.extend(torch.argmax(logits, dim=-1).cpu().tolist())
    print("ALL-labels:", alllabels)
    print("ALL-preds", allpreds)
    # TP—-将正类预测为正类数
    TP = sum([int(i == j == 1) for i, j in zip(alllabels, allpreds)])
    # FN—-将正类预测为负类数
    FN = sum([int(i != j == 0) for i, j in zip(alllabels, allpreds)])
    # FP—-将负类预测为正类数
    FP = sum([int(i != j == 1) for i, j in zip(alllabels, allpreds)])
    # TN—-将负类预测为负类数
    TN = sum([int(i == j == 0) for i, j in zip(alllabels, allpreds)])
    # 正样本总数T
    T = TP + FN
    # 负样本总数F
    F = FP + TN
    # 准确度Acc:正确预测的样本占所有样本的比重
    Acc = (TP + TN) / (T + F)
    # 精确率/查准率:Pre:预测为正的样本中真正为正的比例
    # Pre = TP / (TP + FP)
    # 查全率/召回率Rec:所有正样本中被正确预测的比重
    Rec = TP / T
    # F1值：F1:精确率和召回率的调和平均值
    # F1 = 1 / Pre + 1 / Rec
    # 漏警值MA：所有正样本中被漏判的比重
    MA = FN / T
    # 虚警率FA：预测为正的样本中负样本所占比例
    # FA = FP / (TP + FP)
    # # 定义一组真实数据
    # predicted_data = allpreds
    # # 调用calculate_the_MAE函数计算平均绝对误差
    # actual_data = alllabels
    # the_sum_of_error = 0
    # # 开始逐渐遍历每一个样本
    # for i in range(len(actual_data)):
    #     # 不断累加求和，计算所有样本的绝对误差之和
    #     the_sum_of_error += abs(predicted_data[i] - actual_data[i])
    #     # 计算所有样本的平均绝对误差
    # MAE = the_sum_of_error / float(len(actual_data))
    # Mean_Absolute_Error = calculate_the_MAE(predicted_data, actual_data)

    # print("MAE:", MAE)
    # return MAE

    # from math import sqrt
    # the_sum_of_error = 0
    # # 开始逐渐遍历每一个样本
    # for i in range(len(actual_data)):
    #     # 计算预测数据与真实数据的误差
    #     predition_error = predicted_data[i] - actual_data[i]
    #     # 不断累加求和，计算所有样本的平方误差之和
    #     the_sum_of_error += predition_error ** 2
    # # 计算所有样本的均方根误差
    # RMSE = sqrt(the_sum_of_error / float(len(actual_data)))
    # # rmse = calculate_the_RMSE(predicted_data, actual_data)

    # print("RMESE:", RMSE)
    # acc = sum([int(i==j) for i,j in zip(allpreds, alllabels)])/len(allpreds)
    # return acc
    result = "Acc:"+f"{Acc}"+"--"+"Rec:"+f"{Rec}"+"--"+"MA:"+f"{MA}"
    # +"--"+"F1:"+f"{F1}"+"--"+"FA:"+f"{FA}"
    # result = "Acc=" + f"{Acc}"
    # + "\n" + "Pre:" + f"{Pre}" + "\n" + "Rec:" + f"{Rec}"
    # result = "Acc:" + f"{Acc}"
    return result

    # def calculate_the_MAE(predicted_data, actual_data):
    #     '''
    #     该函数用于计算平均绝对误差
    #     Parameters
    #     ----------
    #     predicted_data : 一维列表
    #         预测数据.
    #     actual_data : 一维列表
    #         真实数据.
    #     Returns
    #     -------
    #     MAE : 浮点型
    #         平均绝对误差.
    #     '''
    # # 定义一个变量用于存储所有样本的绝对误差之和
    #     the_sum_of_error = 0
    #     # 开始逐渐遍历每一个样本
    #     for i in range(len(actual_data)):
    #         # 不断累加求和，计算所有样本的绝对误差之和
    #         the_sum_of_error += abs(predicted_data[i] - actual_data[i])
    #     # 计算所有样本的平均绝对误差
    #         MAE = the_sum_of_error / float(len(actual_data))
    #
    #     return MAE
    #
    # if '__main__' == __name__:
    #     # 定义一组真实数据
    #     predicted_data = allpreds
    #     # 调用calculate_the_MAE函数计算平均绝对误差
    #     actual_data = alllabels
    #     Mean_Absolute_Error = calculate_the_MAE(predicted_data, actual_data)
    #     print("MAE:", Mean_Absolute_Error)

    # 导入包
    # from math import sqrt
    #
    # def calculate_the_RMSE(predicted_data, actual_data):
    #
    #     # 定义一个变量用于存储所有样本的平方误差之和
    #     the_sum_of_error = 0
    #     # 开始逐渐遍历每一个样本
    #     for i in range(len(actual_data)):
    #         # 计算预测数据与真实数据的误差
    #         predition_error = predicted_data[i] - actual_data[i]
    #         # 不断累加求和，计算所有样本的平方误差之和
    #         the_sum_of_error += predition_error ** 2
    #     # 计算所有样本的均方根误差
    #     RMSE = sqrt(the_sum_of_error / float(len(actual_data)))
    #     return RMSE

    # if '__main__' == __name__:
    #     # 调用calculate_the_RMSE函数计算均方根误差
    #     rmse = calculate_the_RMSE(predicted_data, actual_data)
    #     print("RMESE:", rmse)


from transformers import AdamW, get_linear_schedule_with_warmup

# 交叉熵损失：将Log_Softmax()激活函数与NLLLoss()损失函数的功能综合在一起
loss_func = torch.nn.CrossEntropyLoss()


def prompt_initialize(verbalizer, prompt_model, init_dataloader):
    dataloader = init_dataloader
    with torch.no_grad():
        for batch in tqdm(dataloader, desc="Init_using_{}".format("train")):
            batch = batch.cuda()
            logits = prompt_model(batch)
        verbalizer.optimize_to_initialize()


if args.verbalizer == "soft":
    no_decay = ['bias', 'LayerNorm.weight']
    # it's always good practice to set no decay to biase and LayerNorm parameters
    optimizer_grouped_parameters1 = [
        {'params': [p for n, p in prompt_model.plm.named_parameters() if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in prompt_model.plm.named_parameters() if any(nd in n for nd in no_decay)],
         'weight_decay': 0.0}
    ]
    # Using different optimizer for prompt parameters and model parameters

    optimizer_grouped_parameters2 = [
        {'params': prompt_model.verbalizer.group_parameters_1, "lr": args.learning_rate},
        {'params': prompt_model.verbalizer.group_parameters_2, "lr": args.learning_rate},
    ]
    optimizer1 = AdamW(optimizer_grouped_parameters1, lr=args.learning_rate)
    optimizer2 = AdamW(optimizer_grouped_parameters2)

    tot_step = len(train_dataloader) // args.gradient_accumulation_steps * args.max_epochs
    scheduler1 = get_linear_schedule_with_warmup(optimizer1, num_warmup_steps=0, num_training_steps=tot_step)

    scheduler2 = get_linear_schedule_with_warmup(optimizer2, num_warmup_steps=0, num_training_steps=tot_step)

elif args.verbalizer == "auto":
    prompt_initialize(myverbalizer, prompt_model, train_dataloader)
    no_decay = ['bias', 'LayerNorm.weight']

    # it's always good practice to set no decay to biase and LayerNorm parameters
    optimizer_grouped_parameters1 = [
        {'params': [p for n, p in prompt_model.plm.named_parameters() if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in prompt_model.plm.named_parameters() if any(nd in n for nd in no_decay)],
         'weight_decay': 0.0}
    ]

    # Using different optimizer for prompt parameters and model parameters
    optimizer1 = AdamW(optimizer_grouped_parameters1, lr=args.learning_rate)

    tot_step = len(train_dataloader) // args.gradient_accumulation_steps * args.max_epochs
    scheduler1 = get_linear_schedule_with_warmup(
        optimizer1,
        num_warmup_steps=0, num_training_steps=tot_step)

    optimizer2 = None
    scheduler2 = None

elif args.verbalizer == "kpt":
    no_decay = ['bias', 'LayerNorm.weight']

    # it's always good practice to set no decay to biase and LayerNorm parameters
    optimizer_grouped_parameters1 = [
        {'params': [p for n, p in prompt_model.plm.named_parameters() if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in prompt_model.plm.named_parameters() if any(nd in n for nd in no_decay)],
         'weight_decay': 0.0}
    ]

    # Using different optimizer for prompt parameters and model parameters

    # optimizer_grouped_parameters2 = [
    #     {'params': , "lr":1e-1},
    # ]
    optimizer1 = AdamW(optimizer_grouped_parameters1, lr=args.learning_rate)

    optimizer2 = AdamW(prompt_model.verbalizer.parameters(), lr=args.kptw_lr)
    # print(optimizer_grouped_parameters2)

    tot_step = len(train_dataloader) // args.gradient_accumulation_steps * args.max_epochs
    scheduler1 = get_linear_schedule_with_warmup(
        optimizer1,
        num_warmup_steps=0, num_training_steps=tot_step)

    # scheduler2 = get_linear_schedule_with_warmup(
    #     optimizer2,
    #     num_warmup_steps=0, num_training_steps=tot_step)
    scheduler2 = None

elif args.verbalizer == "manual":
    no_decay = ['bias', 'LayerNorm.weight']

    # it's always good practice to set no decay to biase and LayerNorm parameters
    optimizer_grouped_parameters1 = [
        {'params': [p for n, p in prompt_model.plm.named_parameters() if not any(nd in n for nd in no_decay)],
         'weight_decay': 0.01},
        {'params': [p for n, p in prompt_model.plm.named_parameters() if any(nd in n for nd in no_decay)],
         'weight_decay': 0.0}
    ]

    # Using different optimizer for prompt parameters and model parameters

    optimizer1 = AdamW(optimizer_grouped_parameters1, lr=args.learning_rate)

    tot_step = len(train_dataloader) // args.gradient_accumulation_steps * args.max_epochs
    scheduler1 = get_linear_schedule_with_warmup(
        optimizer1,
        num_warmup_steps=0, num_training_steps=tot_step)

    optimizer2 = None
    scheduler2 = None

#  第七步： 训练和测试

tot_loss = 0
log_loss = 0
best_val_acc = 0
for epoch in range(args.max_epochs):
    tot_loss = 0
    prompt_model.train()
    for step, inputs in enumerate(train_dataloader):
        if use_cuda:
            inputs = inputs.cuda()
        logits = prompt_model(inputs)
        labels = inputs['label']
        # print(logits,labels)
        loss = loss_func(logits, labels)
        loss.backward()
        # 梯度裁剪：在BP过程中会产生梯度消失（即偏导无限接近0，导致长时记忆无法更新），
        # 那么最简单粗暴的方法，设定阈值，当梯度小于阈值时，更新的梯度为阈值（梯度裁剪解决的是梯度消失或爆炸的问题，即设定阈值），
        torch.nn.utils.clip_grad_norm_(prompt_model.parameters(), 1.0)
        tot_loss += loss.item()
        optimizer1.step()
        scheduler1.step()
        optimizer1.zero_grad()
        if optimizer2 is not None:
            optimizer2.step()
            optimizer2.zero_grad()
        if scheduler2 is not None:
            scheduler2.step()

    # val_acc = evaluate1(prompt_model, validation_dataloader, desc="Valid")
    val_acc = evaluate1(prompt_model, validation_dataloader, desc="Valid")
    if val_acc >= best_val_acc:
        torch.save(prompt_model.state_dict(), f"./ckpts/{this_run_unicode}.ckpt")
        best_val_acc = val_acc
    print("Epoch {}, val_acc {}".format(epoch + 1, val_acc), flush=True)

prompt_model.load_state_dict(torch.load(f"./ckpts/{this_run_unicode}.ckpt"))
# prompt_model = prompt_model.cuda()
test_result = evaluate2(prompt_model, test_dataloader, desc="Test")
# test_MAE = evaluate2(prompt_model, test_dataloader, desc="Test")

content_write = f"dataset={args.dataset}\t"
content_write += f"verb={args.verbalizer}\t"
content_write += f"cali={args.calibration}\t"
content_write += f"filt={args.filter}\t"
content_write += f"maxsplit={args.max_token_split}\t"
content_write += f"kptw_lr={args.kptw_lr}\t"
content_write += f"temp={args.template_id}\t"
content_write += f"seed={args.seed}\t"
content_write += f"shot={args.shot}\t"
content_write += f"learning_rate {args.learning_rate}\t"
content_write += f"batch_size={args.batch_size}\t"
content_write += f"{test_result}"
content_write += "\n"

print(content_write)

with open(f"{args.result_file}", "a") as fout:
    fout.write(content_write)

# import os
#
# os.remove(f"./ckpts/{this_run_unicode}.ckpt")
